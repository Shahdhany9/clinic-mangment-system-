# 🏥 Clinic Management System Project

## 📌 Overview
This project is a relational database system designed to manage clinic operations efficiently.  
It supports management of **Clinics, Departments, Doctors, Patients, and Appointments** through structured SQL logic and entity relationships.

---

## 📁 Project Structure

/ (root)
├── README.md               ← You're here!
├── report.docx             ← Detailed documentation
├── presentation.pptx       ← Project presentation slides (optional)
├── video_link.txt          ← Link to walkthrough video (optional)
├── /sql/
│   ├── create_tables.sql   ← SQL scripts to create all tables (DDL)
│   ├── load_data.sql       ← Sample data inserts (DML)
│   ├── queries.sql         ← Sample queries (SELECT, UPDATE, DELETE)
│   └── triggers.sql        ← Triggers for automation/data validation
└── /src/                   ← Optional: any frontend/backend code


---

## ⚙️ How to Run

1. Open **MySQL Workbench** or any MySQL-compatible client.
2. Execute `create_tables.sql` to generate all database tables.
3. Run `load_data.sql` to populate tables with sample data (10+ rows/table).
4. Execute `triggers.sql` to apply any defined triggers.
5. Test functionality using queries in `queries.sql`.

---

## 👨‍💻 Team Members
- **Team Leader**: Shahd Hany 
- **Members**: Basma Maher , Shahd Mohamed 

---

## 📝 Notes
- The system design includes ERD, schema mapping, constraints, and trigger logic.
- All test data and queries have been validated successfully.
- No application/UI included for this version.

---

> 💡 Pro Tip: Clone the repo, import the `.sql` files into your local MySQL server, and test queries to explore the system live!
