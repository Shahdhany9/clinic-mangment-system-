CREATE DATABASE clinic_db;
USE clinic_db;

CREATE TABLE Department (
    Department_ID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(200),
    Description VARCHAR(300)
);

CREATE TABLE Clinic (
    Clinic_ID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(200),
    Address VARCHAR(250),
    Department_ID INT,
    FOREIGN KEY (Department_ID) REFERENCES Department(Department_ID)
);

CREATE TABLE Doctor (
    Doctor_ID INT PRIMARY KEY,
    Name VARCHAR(200),
    Phone_Number VARCHAR(20),
    Address VARCHAR(250),
    Department_ID INT,
    FOREIGN KEY (Department_ID) REFERENCES Department(Department_ID)
);

CREATE TABLE Patient (
    Patient_ID INT PRIMARY KEY,
    Name VARCHAR(200),
    Phone_Number VARCHAR(20),
    Address VARCHAR(250),
    Birth_Date DATE,
    Job VARCHAR(150)
);

CREATE TABLE Appointment (
    Appointment_ID INT AUTO_INCREMENT PRIMARY KEY,
    Date DATE,
    Start_Time TIME,
    End_Time TIME,
    Cost DECIMAL(10,2),
    Status ENUM('Scheduled','In Progress','Postponed'),
    Patient_Diagnosis VARCHAR(250),
    Patient_ID INT,
    Doctor_ID INT,
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID),
    FOREIGN KEY (Doctor_ID) REFERENCES Doctor(Doctor_ID)
);