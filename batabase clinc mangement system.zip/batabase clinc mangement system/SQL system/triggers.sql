USE clinic_db;

DELIMITER $$

CREATE TRIGGER prevent_double_booking
BEFORE INSERT ON Appointment
FOR EACH ROW
BEGIN
    DECLARE existing INT;
    SELECT COUNT(*) INTO existing FROM Appointment
    WHERE Doctor_ID = NEW.Doctor_ID AND Date = NEW.Date AND Start_Time = NEW.Start_Time;
    
    IF existing > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Doctor already has an appointment at this time.';
    END IF;
END $$

DELIMITER ;
