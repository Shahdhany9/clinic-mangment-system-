USE clinic_db;

SELECT Patient.Name
FROM Patient
JOIN Appointment ON Patient.Patient_ID = Appointment.Patient_ID
WHERE Appointment.Patient_Diagnosis = 'Fatty Liver'
  AND Appointment.Date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR);

SELECT Clinic.Address
FROM Clinic
JOIN Department ON Clinic.Department_ID = Department.Department_ID
WHERE Department.Name = 'Cardiology';

SELECT SUM(Appointment.Cost) AS Total_Cost
FROM Appointment
WHERE Appointment.Patient_ID = 12527
  AND Appointment.Date >= DATE_SUB(CURDATE(), INTERVAL 3 YEAR);

SELECT * FROM Appointment;

SELECT Department_ID, Name FROM Department;

SELECT Appointment_ID, Status, Patient_Diagnosis FROM Appointment
WHERE Status = 'In Progress';

SELECT Address FROM Doctor WHERE Address LIKE '%Cologne, Germany';

SELECT Address FROM Doctor WHERE Address LIKE '%Munich, Germany';

SELECT AVG(Cost) AS Average_Cost FROM Appointment;

SELECT * FROM Doctor ORDER BY Name DESC;

UPDATE Doctor SET Phone_Number = '777-888-9999' WHERE Doctor_ID = 718;

SELECT * FROM Doctor;