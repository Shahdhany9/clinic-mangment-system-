INSERT INTO Department (Name, Description) VALUES
('Cardiology', 'Deals with heart-related issues'),
('Gastroenterology', 'Deals with digestive system disorders'),
('Dermatology', 'Deals with skin-related issues'),
('Ophthalmology', 'Deals with eye-related issues'),
('Orthopedics', 'Deals with musculoskeletal system disorders'),
('Neurology', 'Deals with nervous system disorders'),
('Pediatrics', 'Deals with medical care of infants, children, and adolescents'),
('Urology', 'Deals with urinary tract system'),
('Endocrinology', 'Deals with hormonal disorders'),
('Oncology', 'Deals with cancer treatment');

INSERT INTO Clinic (Name, Address, Department_ID) VALUES
('Heart Care Clinic', '123 Main St, Berlin, Germany', 1),
('Digestive Health Clinic', '456 Oak St, Hamburg, Germany', 2),
('Dermatology Center', '789 Elm St, Munich, Germany', 3),
('Eye Care Center', '101 Maple St, Cologne, Germany', 4),
('Ortho Center', '202 Oak St, Essen, Germany', 5),
('Neurology Clinic', '303 Pine St, Bremen, Germany', 6),
('Pediatric Care Center', '404 Cedar St, Dresden, Germany', 7),
('Head Care Clinic', '310 Pine St, Bremen, Germany', 8),
('Joint Health Clinic', '808 Elmwood St, Nuremberg, Germany', 9),
('Ears Care Center', '410 Cedar St, Dresden, Germany', 10);

INSERT INTO Doctor (Doctor_ID, Name, Phone_Number, Address, Department_ID) VALUES
(123,'Dr. Smith', '123-456-7890', '789 Elm St, Munich, Germany', 1),
(456,'Dr. Johnson', '456-789-0123', '567 Pine St, Bremen, Germany', 2),
(789,'Dr. Williams', '789-012-3456', '345 Cedar St, Dresden, Germany', 3),
(101,'Dr. Brown', '012-345-6789', '123 Oak St, Hamburg, Germany', 4),
(121,'Dr. Jones', '234-567-8901', '890 Maple St, Cologne, Germany', 5),
(131,'Dr. Garcia', '567-890-1234', '456 Elmwood St, Cologne, Germany', 6),
(141,'Dr. Martinez', '890-123-4567', '234 Pinecrest St, Munich, Germany', 6),
(516,'Dr. Fares', '890-663-4567', '234 Pinecrest St, Munich, Germany', 7),
(718,'Dr. Kermena', '890-993-4567', '234 Pinecrest St, Munich, Germany', 7),
(819,'Dr. Patel', '901-234-5678', '345 Cedar St, Dresden, Germany', 8);

INSERT INTO Patient (Patient_ID, Name, Phone_Number, Address, Birth_Date, Job) VALUES
(12527,'John Doe', '111-222-3333', '101 Maple St, Cologne, Germany', '1980-01-01', 'Engineer'),
(12346,'Jane Smith', '444-555-6666', '202 Oak St, Hamburg, Germany', '1990-05-15', 'Teacher'),
(12345,'Mary Johnson', '777-888-9999', '303 Pine St, Bremen, Germany', '1975-10-20', 'Nurse'),
(78910,'David Williams', '222-333-4444', '404 Cedar St, Dresden, Germany', '1988-03-05', 'Doctor'),
(11213,'Michael Brown', '555-666-7777', '505 Walnut St, Hamburg, Germany', '1982-07-12', 'Lawyer'),
(41516,'Jennifer Jones', '888-999-0000', '606 Birch St, Hamburg, Germany', '1995-12-30', 'Artist'),
(71819,'Linda Garcia', '333-444-5555', '707 Elmwood St, Cologne, Germany', '1970-08-25', 'Dentist'),
(82120,'Robert Miller', '111-333-5555', '808 Pinecrest St, Munich, Germany', '1985-09-15', 'Architect'),
(92221,'Susan Wilson', '222-444-6666', '909 Elmwood St, Munich, Germany', '1978-11-22', 'Pharmacist'),
(102322,'James Davis', '333-555-7777', '1010 Cedar St, Dresden, Germany', '1983-04-10', 'Scientist');

INSERT INTO Appointment (Date, Patient_ID, Doctor_ID, Start_Time, End_Time, Cost, Status, Patient_Diagnosis) VALUES
('2023-09-01', 12527, 123, '10:00:00', '11:00:00', 100.00, 'Scheduled', 'Fatty Liver'),
('2023-09-15', 12346, 456, '14:00:00', '15:00:00', 150.00, 'In Progress', 'Hypertension'),
('2023-07-03', 12345, 789, '09:00:00', '10:00:00', 120.00, 'Scheduled', 'Fatty Liver'),
('2023-08-20', 78910, 789, '11:00:00', '12:00:00', 130.00, 'In Progress', 'Eye Infection'),
('2023-09-10', 78910, 121, '15:00:00', '16:00:00', 140.00, 'Scheduled', 'Knee Pain'),
('2023-10-05', 12527, 121, '08:00:00', '09:00:00', 160.00, 'In Progress', 'Migraine'),
('2023-11-12', 71819, 131, '13:00:00', '14:00:00', 170.00, 'Scheduled', 'Childhood Illness'),
('2023-09-22', 82120, 141, '10:00:00', '11:00:00', 180.00, 'Scheduled', 'Urinary Tract Infection'),
('2023-10-10', 92221, 516, '14:00:00', '15:00:00', 190.00, 'In Progress', 'Hormonal Imbalance'),
('2023-07-30', 102322, 718, '09:00:00', '10:00:00', 200.00, 'Scheduled', 'Diabetes');